//
//  Search_Bar_L8App.swift
//  Search_Bar_L8
//
//  Created by ilyas uyanik on 3/16/25.
//

import SwiftUI

@main
struct Search_Bar_L8App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
