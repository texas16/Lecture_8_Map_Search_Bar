//
//  ContentView.swift
//  Search_Bar_L8
//
//  Created by ilyas uyanik on 3/16/25.
//

import SwiftUI

struct ContentView: View {
    
    @State private var searchText = ""
    
    var fruits = ["Apple", "Banana", "Strawberry", "Grape", "Fig"]
    
    // computed property
    var filteredFruits :[String] {
        if searchText.isEmpty {
            return fruits
        } else {
            return fruits.filter {
                $0.localizedCaseInsensitiveContains(searchText)
            }
        }
    }
    
    var body: some View {
        VStack {
            NavigationView {
                List(filteredFruits, id: \.self) { fruit in
                    Text(fruit)
                }
                .navigationTitle("Fruits")
                .searchable(text: $searchText, prompt: "Search fruits")
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}

// Map
    // Region - CLLocationCoordinate2D - lat, long
    // Span - zoom parameters
    // api call
    // custom models

// Search
    // filter
    // add the searchbar with List
