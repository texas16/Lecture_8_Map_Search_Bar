//
//  Lecture_8_MapApp.swift
//  Lecture_8_Map
//
//  Created by ilyas uyanik on 3/16/25.
//

import SwiftUI

@main
struct Lecture_8_MapApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
