//
//  WeatherResponse.swift
//  Lecture_8_Map
//
//  Created by ilyas uyanik on 3/16/25.
//

import Foundation

struct WeatherResponse: Decodable {
    let current_weather: CurrentWeather
}
