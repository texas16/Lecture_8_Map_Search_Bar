//
//  CurrentWeather.swift
//  Lecture_8_Map
//
//  Created by ilyas uyanik on 3/16/25.
//

import Foundation

struct CurrentWeather: Decodable {
    let temperature: Double
}
