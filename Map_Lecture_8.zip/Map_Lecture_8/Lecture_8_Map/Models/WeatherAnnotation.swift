//
//  WeatherAnnotation.swift
//  Lecture_8_Map
//
//  Created by ilyas uyanik on 3/16/25.
//

import Foundation
import MapKit

struct WeatherAnnotation: Identifiable {
    var id = UUID()
    var coordinate: CLLocationCoordinate2D
    var temperature: String = "N/A"
}
