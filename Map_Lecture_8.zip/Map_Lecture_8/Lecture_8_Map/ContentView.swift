//
//  ContentView.swift
//  Lecture_8_Map
//
//  Created by ilyas uyanik on 3/16/25.
//

import SwiftUI
import MapKit

struct ContentView: View {
    // initial map settings
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 42.8746, longitude: 74.5698),
        span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
    )
    
    // Array of annotations added by the user
    @State private var annotations : [WeatherAnnotation] = []
    
    var body: some View {
        VStack {
            // Map view with annotations
            Map(coordinateRegion: $region, annotationItems: annotations) { annotation in
                // creating custom map annoation
                MapAnnotation(coordinate: annotation.coordinate) {
                    VStack {
                        Image(systemName: "mappin.circle.fill")
                            .font(.title)
                            .foregroundColor(.red)
                        Text("\(annotation.temperature) C")
                            .font(.caption)
                            .padding(4)
                    }
                }
            }
            .frame(height:300)
            .cornerRadius(10)
            .padding()
            
            Button("Add Pin at the Center") {
                addPinAtCenter()
            }
            .padding()
        }
    }
    
    private func addPinAtCenter() {
        let centerCoordinate = region.center // returns latitude and longitude
        let newAnnoation = WeatherAnnotation(coordinate: centerCoordinate)
        
        annotations.append(newAnnoation)
        
        fetchWeather(for: centerCoordinate) { temperature in
            if let index = annotations.firstIndex(where: {$0.id == newAnnoation.id}) {
                annotations[index].temperature = temperature
            }
        }
    }
    
    private func fetchWeather(for coordinate: CLLocationCoordinate2D, completion: @escaping(String) -> Void) {
        let lat = coordinate.latitude
        let lon = coordinate.longitude
        
        guard let url = URL(string: "https://api.open-meteo.com/v1/forecast?latitude=\(lat)&longitude=\(lon)&current_weather=true") else {
            completion("N/A")
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            
            // check if we have any errors
            if error != nil {
                completion("N/A")
                return
            }
            
            // check if we have data
            guard let data = data  else {
                completion("N/A")
                return
            }
            
            do {
                let weatherResponse = try JSONDecoder().decode(WeatherResponse.self, from: data)
                let tempString = String(format: "%.1f", weatherResponse.current_weather.temperature)
                
                DispatchQueue.main.async {
                    completion(tempString)
                }
                
            } catch {
                DispatchQueue.main.async {
                    completion("N/A")
                }
            }
        }.resume()
    }
}

#Preview {
    ContentView()
}
